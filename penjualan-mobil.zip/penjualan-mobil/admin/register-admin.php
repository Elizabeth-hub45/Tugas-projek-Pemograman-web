<?php
session_start();
include '../config/koneksi.php';

if (isset($_SESSION['admin'])) {
    header("Location: dashboard.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $konfirmasi = $_POST['konfirmasi'];

    // Cek apakah username sudah terdaftar
    $cek = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$username'");
    if (mysqli_num_rows($cek) > 0) {
        $error = "Username sudah digunakan!";
    } elseif ($password !== $konfirmasi) {
        $error = "Konfirmasi password tidak cocok!";
    } else {
        // Simpan admin baru
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $simpan = mysqli_query($conn, "INSERT INTO admin (username, password) VALUES ('$username', '$hash')");

        if ($simpan) {
            $_SESSION['admin'] = $username;
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Gagal menyimpan data admin!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Registrasi Admin</title>
    <link rel="stylesheet" href="../css/login-admin.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="logo-container">
                <img src="../img/logo/logo.png" alt="Logo Mobil" class="logo">
            </div>
            <h2 class="login-title">Registrasi Admin</h2>
            <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

            <form action="" method="POST" class="login-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="konfirmasi">Konfirmasi Password</label>
                    <input type="password" id="konfirmasi" name="konfirmasi" class="form-control" required>
                </div>

                <button type="submit" class="login-button">Daftar Sekarang</button>
            </form>

            <div class="text-center mt-3">
                <p>Sudah punya akun? <a href="login-admin.php">Login di sini</a></p>
            </div>
        </div>
    </div>
</body>
</html>
