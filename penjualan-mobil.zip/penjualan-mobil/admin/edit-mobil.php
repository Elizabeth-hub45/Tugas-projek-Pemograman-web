<?php
include '../config/koneksi.php';

if (!isset($_GET['id'])) {
    echo "ID mobil tidak ditemukan.";
    exit;
}

$id = $_GET['id'];
$query = mysqli_query($conn, "SELECT * FROM mobil WHERE id_mobil = $id");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "Mobil tidak ditemukan.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Mobil</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">

    <h2>Edit Mobil: <?= $data['nama_mobil'] ?></h2>

    <form action="proses-edit.php" method="POST" enctype="multipart/form-data" class="mt-4">
        <input type="hidden" name="id_mobil" value="<?= $data['id_mobil'] ?>">

        <div class="mb-3">
            <label>Nama Mobil</label>
            <input type="text" name="nama_mobil" class="form-control" value="<?= $data['nama_mobil'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Merk</label>
            <input type="text" name="merk" class="form-control" value="<?= $data['merk'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Tahun</label>
            <input type="number" name="tahun" class="form-control" value="<?= $data['tahun'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Harga</label>
            <input type="number" name="harga" class="form-control" value="<?= $data['harga'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="deskripsi" class="form-control"><?= $data['deskripsi'] ?></textarea>
        </div>

        <div class="mb-3">
            <label>Ganti Gambar (kosongkan jika tidak ingin mengubah)</label>
            <input type="file" name="gambar" class="form-control">
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-control">
                <option value="tersedia" <?= $data['status'] == 'tersedia' ? 'selected' : '' ?>>Tersedia</option>
                <option value="terjual" <?= $data['status'] == 'terjual' ? 'selected' : '' ?>>Terjual</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>

</body>
</html>
