<?php
include '../config/koneksi.php';

$password = password_hash('admin123', PASSWORD_DEFAULT); // bikin hash baru
$update = mysqli_query($conn, "UPDATE admin SET password = '$password' WHERE username = 'admin'");

if ($update) {
    echo "✅ Password admin berhasil direset ke: <b>admin123</b>";
} else {
    echo "❌ Gagal: " . mysqli_error($conn);
}
