<?php
include '../config/koneksi.php';

$nama_mobil = $_POST['nama_mobil'];
$merk       = $_POST['merk'];
$tahun      = $_POST['tahun'];
$harga      = $_POST['harga'];
$deskripsi  = $_POST['deskripsi'];

$gambar     = $_FILES['gambar']['name'];
$tmp        = $_FILES['gambar']['tmp_name'];
$path       = "../img/" . $gambar;

// Cek upload gambar berhasil atau tidak
if (move_uploaded_file($tmp, $path)) {
    $query = "INSERT INTO mobil (nama_mobil, merk, tahun, harga, deskripsi, gambar, status)
              VALUES ('$nama_mobil', '$merk', $tahun, $harga, '$deskripsi', '$gambar', 'tersedia')";

    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "<script>alert('Data berhasil ditambahkan'); window.location='dashboard.php';</script>";
    } else {
        echo "Query gagal: " . mysqli_error($conn);
    }
} else {
    echo "Upload gambar gagal!";
}
?>
