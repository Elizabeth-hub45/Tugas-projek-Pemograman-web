<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="dashboard-umum.php">MobilStore</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="dashboard-umum.php">Beranda</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="daftar-mobil.php">Daftar Mobil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#kontak">Kontak</a>
        </li>
        <li class="nav-item">
          <a class="nav-link btn btn-sm btn-outline-light ms-2" href="login.php">Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
