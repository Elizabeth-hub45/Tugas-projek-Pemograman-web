<?php
include '../config/koneksi.php';

$id_mobil    = $_POST['id_mobil'];
$nama_mobil  = $_POST['nama_mobil'];
$merk        = $_POST['merk'];
$tahun       = $_POST['tahun'];
$harga       = $_POST['harga'];
$deskripsi   = $_POST['deskripsi'];
$status      = $_POST['status'];

$gambar      = $_FILES['gambar']['name'];
$tmp         = $_FILES['gambar']['tmp_name'];

if (!empty($gambar)) {
    // Ambil gambar lama
    $q = mysqli_query($conn, "SELECT gambar FROM mobil WHERE id_mobil = $id_mobil");
    $d = mysqli_fetch_assoc($q);
    $gambar_lama = "../img/" . $d['gambar'];
    if (file_exists($gambar_lama)) {
        unlink($gambar_lama); // hapus gambar lama
    }

    // Upload gambar baru
    $path = "../img/" . $gambar;
    move_uploaded_file($tmp, $path);

    $sql = "UPDATE mobil SET 
            nama_mobil = '$nama_mobil',
            merk = '$merk',
            tahun = $tahun,
            harga = $harga,
            deskripsi = '$deskripsi',
            gambar = '$gambar',
            status = '$status'
            WHERE id_mobil = $id_mobil";
} else {
    $sql = "UPDATE mobil SET 
            nama_mobil = '$nama_mobil',
            merk = '$merk',
            tahun = $tahun,
            harga = $harga,
            deskripsi = '$deskripsi',
            status = '$status'
            WHERE id_mobil = $id_mobil";
}

if (mysqli_query($conn, $sql)) {
    echo "<script>alert('Data berhasil diupdate'); window.location='dashboard.php';</script>";
} else {
    echo "Gagal update data: " . mysqli_error($conn);
}
?>
