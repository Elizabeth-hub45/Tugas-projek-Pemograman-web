<?php
include '../config/koneksi.php';

$id = $_GET['id'];

// ambil gambar terlebih dahulu
$cek = mysqli_query($conn, "SELECT gambar FROM mobil WHERE id_mobil = $id");
$data = mysqli_fetch_assoc($cek);

if ($data) {
    $gambar = "../img/" . $data['gambar'];
    if (file_exists($gambar)) {
        unlink($gambar); // hapus file gambar
    }
    mysqli_query($conn, "DELETE FROM mobil WHERE id_mobil = $id");
    echo "<script>alert('Mobil berhasil dihapus'); window.location='dashboard.php';</script>";
} else {
    echo "Data tidak ditemukan.";
}
?>
