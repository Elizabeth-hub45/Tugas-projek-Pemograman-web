<?php
session_start();
include '../config/koneksi.php';

// Cek apakah sudah login sebagai admin
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<?php include 'layout/navbar.php'; ?> <!-- Navbar Admin -->

<div class="container mt-5">

    <!-- Header dan Tombol Aksi -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Dashboard Admin</h2>
        <div>
            <a href="tambah-mobil.php" class="btn btn-success">+ Tambah Mobil</a>
            <a href="../dashboard_umum.php" target="_blank" class="btn btn-outline-primary">🔍 Lihat Tampilan Umum</a>
        </div>
    </div>

    <!-- Tabel Data Mobil -->
    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Gambar</th>
                <th>Nama Mobil</th>
                <th>Merk</th>
                <th>Tahun</th>
                <th>Harga</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $query = mysqli_query($conn, "SELECT * FROM mobil ORDER BY tanggal_input DESC");
            while ($data = mysqli_fetch_array($query)) {
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><img src="../img/<?= $data['gambar'] ?>" width="80"></td>
                <td><?= $data['nama_mobil'] ?></td>
                <td><?= $data['merk'] ?></td>
                <td><?= $data['tahun'] ?></td>
                <td>Rp <?= number_format($data['harga'], 0, ',', '.') ?></td>
                <td><?= $data['status'] ?></td>
                <td>
                    <a href="edit-mobil.php?id=<?= $data['id_mobil'] ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="hapus-mobil.php?id=<?= $data['id_mobil'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus mobil ini?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

</div> <!-- Tutup container -->

</body>
</html>
