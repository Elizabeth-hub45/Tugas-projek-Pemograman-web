<?php
session_start();
include '../config/koneksi.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kelola Kategori Mobil</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<?php include 'layout/navbar.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4">Kategori Mobil</h2>

    <form method="POST" class="mb-4 d-flex" action="">
        <input type="text" name="nama_kategori" class="form-control me-2" placeholder="Kategori baru..." required>
        <button type="submit" name="tambah" class="btn btn-success">Tambah</button>
    </form>

    <?php
    // Handle penambahan kategori
    if (isset($_POST['tambah'])) {
        $nama = htmlspecialchars($_POST['nama_kategori']);
        $cek = mysqli_query($conn, "SELECT * FROM kategori WHERE nama_kategori = '$nama'");
        if (mysqli_num_rows($cek) == 0) {
            mysqli_query($conn, "INSERT INTO kategori (nama_kategori) VALUES ('$nama')");
            echo "<div class='alert alert-success'>Kategori berhasil ditambahkan.</div>";
        } else {
            echo "<div class='alert alert-warning'>Kategori sudah ada.</div>";
        }
    }

    // Handle hapus
    if (isset($_GET['hapus'])) {
        $id = $_GET['hapus'];
        mysqli_query($conn, "DELETE FROM kategori WHERE id_kategori = $id");
        echo "<div class='alert alert-danger'>Kategori dihapus.</div>";
    }
    ?>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama Kategori</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $data = mysqli_query($conn, "SELECT * FROM kategori ORDER BY id_kategori DESC");
            while ($row = mysqli_fetch_assoc($data)) {
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
                <td>
                    <a href="?hapus=<?= $row['id_kategori'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus kategori ini?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>
