<?php
session_start();
include '../config/koneksi.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Pesanan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<?php include 'layout/navbar.php'; ?> <!-- ✅ Tambahkan navbar -->

<div class="container mt-5">
    <h2 class="mb-4">Daftar Pesanan Mobil</h2>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama Pemesan</th>
                <th>Mobil</th>
                <th>No HP</th>
                <th>Email</th>
                <th>Pesan</th>
                <th>Tanggal Pesan</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $query = mysqli_query($conn, "
                SELECT p.*, m.nama_mobil 
                FROM pesanan p
                JOIN mobil m ON p.id_mobil = m.id_mobil
                ORDER BY p.tanggal_pesan DESC
            ");

            while ($data = mysqli_fetch_assoc($query)) {
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($data['nama_pemesan']) ?></td>
                <td><?= htmlspecialchars($data['nama_mobil']) ?></td>
                <td><?= htmlspecialchars($data['no_hp']) ?></td>
                <td><?= htmlspecialchars($data['email']) ?></td>
                <td><?= nl2br(htmlspecialchars($data['pesan'])) ?></td>
                <td><?= date('d-m-Y H:i', strtotime($data['tanggal_pesan'])) ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>
