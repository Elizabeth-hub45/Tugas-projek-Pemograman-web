<?php
include '../config/koneksi.php';
session_start();

if (!isset($_SESSION['pelanggan'])) {
    header("Location: login.php");
    exit;
}

$pelanggan = $_SESSION['pelanggan'];

// Tangkap kategori dari URL
$kategori = isset($_GET['kategori']) ? mysqli_real_escape_string($conn, $_GET['kategori']) : '';

// Query mobil berdasarkan kategori
$query = "SELECT * FROM mobil WHERE status = 'tersedia'";
if (!empty($kategori)) {
    $query .= " AND kategori = '$kategori'";
}
$query .= " ORDER BY tanggal_input DESC";

$mobil = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mobil Berdasarkan Kategori</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f9f9f9;
        }
        .mobil-img {
            height: 180px;
            object-fit: cover;
        }
    </style>
</head>
<body>

<!-- Navbar sederhana -->
<nav class="navbar navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="dashboard-pelanggan.php">BETHCARZONE</a>
    </div>
</nav>

<div class="container">
    <h4 class="mb-3">Kategori Mobil: <?= htmlspecialchars($kategori ?: 'Semua') ?></h4>

    <div class="row g-4">
        <?php if ($mobil && mysqli_num_rows($mobil) > 0): ?>
            <?php while ($m = mysqli_fetch_assoc($mobil)): ?>
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm">
                        <img src="../img/<?= htmlspecialchars($m['gambar']) ?>" class="card-img-top mobil-img" alt="<?= $m['nama_mobil'] ?>">
                        <div class="card-body d-flex flex-column">
                            <h5><?= $m['nama_mobil'] ?></h5>
                            <p class="text-muted"><?= $m['merk'] ?> • <?= $m['tahun'] ?></p>
                            <p><?= substr($m['deskripsi'], 0, 60) ?>...</p>
                            <p class="fw-bold text-primary">Rp <?= number_format($m['harga'], 0, ',', '.') ?></p>
                            <a href="../form-pesanan.php?id=<?= $m['id_mobil'] ?>" class="btn btn-success mt-auto w-100">Pesan Sekarang</a>
                            <a href="detail_mobil.php?id=<?= $m['id_mobil'] ?>" class="btn btn-secondary mt-2 w-100">Detail Mobil</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-warning">Tidak ada mobil dalam kategori ini.</div>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
