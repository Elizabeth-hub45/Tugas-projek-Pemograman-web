<?php
// Kalau kamu mau pakai session di index utama:
session_start();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Beranda - BethCarZone</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">

</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm sticky-top">
  <div class="container">
    <a class="navbar-brand" href="#">BethCarZone</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active" href="#home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#cars">Cars</a> <!-- ✅ INI bagian barunya -->
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#kontak">Kontak</a>
        </li>
        <li class="nav-item">
          <a class="btn btn-light text-primary fw-bold" href="login.php">Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>



  <!-- ✅ SLIDER -->
    <div class="slider">
        <div class="slides">
            <img src="../img/slide1.jpg" alt="Slide 1">
            <img src="../img/slide2.jpg" alt="Slide 2">
            <img src="../img/slide3.jpg" alt="Slide 3">
        </div>
        

        <div class="welcome-text">
            <h1>Selamat Datang di BethCarZone 🚗</h1>
            <p>Temukan mobil impian Anda sekarang juga!</p>
            
        </div>
    </div>

    <!-- ✅ SECTION HOME -->
<section class="home" id="home" style="background: url('../img/slide1.jpg') no-repeat center center/cover; height: 100vh; display: flex; align-items: center; position: relative;">
  <div style="background: rgba(0,0,0,0.5); position: absolute; top: 0; bottom: 0; left: 0; right: 0;"></div>

  <div class="container position-relative text-white">
    <div class="row">
      <div class="col-md-8">
        <h1 class="display-4 fw-bold">Kami Punya Semua yang<br><span class="text-warning">Dibutuhkan Mobil</span> Anda</h1>
        <p class="lead mt-3">Temukan berbagai pilihan mobil baru dan bekas dari merek terpercaya.<br>
          Dapatkan penawaran terbaik, proses pembelian mudah, <br>
          <span class="fw-semibold">layanan purna jual yang memuaskan.</span>
        </p>
        <a href="#cars" class="btn btn-light mt-3 btn-lg fw-semibold">Temukan Sekarang</a>
      </div>
    </div>
  </div>
</section>

  <!-- ✅ SECTION CARS -->

<section class="cars py-5 bg-light" id="cars" style="background: url('../img/about.jpg') ">
  <div style="background: rgba(0,0,0,0.5); position: absolute; top: 0; bottom: 0; left: 0; right: 0;"></div>
  <div class="container">
    <div class="text-center mb-5">
      <span class="text-primary fw-semibold">All Cars</span>
      <h2 class="fw-bold mt-2">Kami Mempunyai Semua Jenis Mobil</h2>
      <p class="text-muted">
        Temukan mobil impian Anda dari koleksi lengkap kami. Mulai dari City Car hemat bahan bakar, SUV tangguh untuk petualangan,
        hingga mobil keluarga yang nyaman. <br>
        Tersedia mobil baru maupun bekas berkualitas dengan harga bersahabat dan
        <span class="fw-semibold">proses pembelian yang mudah.</span>
      </p>
    </div>

    <!-- ✅ Container Mobil -->
    <div class="row g-4">
      <!-- Contoh satu box mobil, duplikat bagian ini untuk semua mobil -->
      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Abarth/Abarth 124 Spider serie 2 (348) anni 2016-2019_ scheda tecnica e listino usato.jpg" class="card-img-top" alt="Abarth 124 Spider">
          <div class="card-body text-center">
            <h5 class="card-title">Abarth 124 Spider</h5>
          </div>
        </div>
      </div>
      
      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Abarth/Abarth 500 Gets Alpha N Performance Goodies _ Carscoops.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Abarath 500</h5>
          </div>
        </div>
      </div>
      
      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Abarth/ABARTH 695 TRIBUTO FERRARI TRIBUTO AL GIAPPONE｜コンパクトスポーツカー ABARTH(アバルト).jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Abarath 695</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Honda/2025 Honda CR-V Review_ Expert Insights, Pricing, and Trims.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Honda CR-V</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Acura car/2022 Acura MDX.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Acura MDX</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Acura car/2024 Acura TLX Facelift Is Almost Too Subtle To Notice.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Acura TLX</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Acura car/2024 Acura ZDX Type S First Drive Review_ A Good Car With First-EV Jitters.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Acura ZDX</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Acura car/First Drive_ 2016 Acura ILX.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Acura ILX</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Acura car/Understated Acura RDX one to watch.jpg ">
          <div class="card-body text-center">
            <h5 class="card-title">Acura RDX</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Aion/2024 GAC Motor Aion V - Stunning HD Photos, Videos, Specs, Features & Price - DailyRevs.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Alion V </h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Aion/Aion S_ Green Innovation on Wheels.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Alion S</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Aion/GAC Aion Hyper GT Debuts As The Most Aerodynamic Production EVtets.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Aion Hyper GT</h5>
          </div>
        </div>
      </div>

      
      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Honda/Honda BRV 2024.jpg" class="card-img-top" alt="Honda BRV">
          <div class="card-body text-center">
            <h5 class="card-title">Honda BRV</h5>
          </div>
        </div>
      </div>
      
      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Mitsubishi/2023 Mitsubishi Pajero Sport Launches In Australia With New Features And Colorstets.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">pajero Sport</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/KIA/2024 Kia EV6.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Kia </h5>
          </div>
        </div> 
      </div>

      <div class="col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm border-0">
          <img src="../img/Nissan/Nissan Livina - PHL version.jpg">
          <div class="card-body text-center">
            <h5 class="card-title">Livina </h5>
      <!-- Tambahkan mobil lainnya di sini dengan struktur yang sama -->
    </div>
  </div>
</section>

  
    <!-- ✅ SECTION KONTAK -->
<section id="kontak" class="py-5 bg-white">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="fw-bold">Hubungi Kami</h2>
      <p class="text-muted">Ada pertanyaan atau butuh bantuan? Silakan hubungi kami melalui formulir di bawah ini atau lewat kontak yang tersedia.</p>
    </div>

    <!-- ✅ Footer -->
    <footer>
        <p>Kontak: 0813-6406-8035 | Email: info@bethcarzone.com</p>
    </footer>

</body>
</html>
