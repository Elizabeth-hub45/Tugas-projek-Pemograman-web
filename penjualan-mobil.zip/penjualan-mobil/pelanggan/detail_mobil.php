<?php
session_start();
if (!isset($_SESSION['pelanggan'])) {
    header("Location: login.php");
    exit;
}

include '../config/koneksi.php';

if (!isset($_GET['id'])) {
    echo "ID mobil tidak ditemukan.";
    exit;
}

$id_mobil = intval($_GET['id']);
$query = mysqli_query($conn, "SELECT * FROM mobil WHERE id_mobil = $id_mobil");

if (mysqli_num_rows($query) == 0) {
    echo "Mobil tidak ditemukan.";
    exit;
}

$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Mobil - <?= htmlspecialchars($data['nama_mobil']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f7f9fc;
        }
        .container {
            margin-top: 40px;
        }
        .img-mobil {
            width: 100%;
            max-height: 400px;
            object-fit: contain;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="dashboard-pelanggan.php">BETHCARZONE</a>
    </div>
</nav>

<!-- ✅ Konten -->
<div class="container">
    <a href="daftar-mobil.php" class="btn btn-secondary mb-3">← Kembali ke Daftar Mobil</a>

    <div class="card shadow-lg">
        <div class="row g-0">
            <div class="col-md-6">
                <img src="../img/<?= htmlspecialchars($data['gambar']) ?>" class="img-fluid img-mobil" alt="<?= htmlspecialchars($data['nama_mobil']) ?>">
            </div>
            <div class="col-md-6">
                <div class="card-body">
                    <h3 class="card-title"><?= htmlspecialchars($data['nama_mobil']) ?></h3>
                    <p class="text-muted">
                        Merek: <?= htmlspecialchars($data['merk']) ?><br>
                        Tahun: <?= htmlspecialchars($data['tahun']) ?><br>
                        Kategori: <?= isset($data['nama_kategori']) ? htmlspecialchars($data['nama_kategori']) : '-' ?>
                    </p>
                    <h4 class="text-primary">Rp <?= number_format($data['harga'], 0, ',', '.') ?></h4>
                    <hr>
                    <p><?= nl2br(htmlspecialchars($data['deskripsi'])) ?></p>

                    <a href="../form-pesanan.php?id=<?= $data['id_mobil'] ?>" class="btn btn-success mt-3">Pesan Sekarang</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
