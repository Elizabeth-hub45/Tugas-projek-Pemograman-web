<?php
session_start();
if (!isset($_SESSION['pelanggan'])) {
    header("Location: login.php");
    exit;
}

include '../config/koneksi.php';
$pelanggan = $_SESSION['pelanggan'];

// Ambil pesanan berdasarkan email pelanggan
$query = mysqli_query($conn, "
    SELECT pesanan.*, mobil.nama_mobil, mobil.gambar, mobil.harga 
    FROM pesanan 
    LEFT JOIN mobil ON pesanan.id_mobil = mobil.id_mobil 
    WHERE email = '{$pelanggan['email']}' 
    ORDER BY id_pesanan DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Riwayat Pesanan Saya</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/dashboard-pelanggan.css">
</head>
<body>

<!-- ✅ Navbar Lengkap -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="dashboard-pelanggan.php">BETHCARZONE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="dashboard-pelanggan.php">Beranda</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="daftar-mobil.php">Daftar Mobil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">Tentang</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="riwayat-pesanan.php">Riwayat</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- ✅ Konten Riwayat -->
<div class="container mt-5">
    <h3>📄 Riwayat Pesanan Anda</h3>
    <hr>

    <?php if (mysqli_num_rows($query) > 0): ?>
        <div class="row g-4">
            <?php while ($p = mysqli_fetch_assoc($query)): ?>
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="../img/<?= $p['gambar'] ?>" class="img-fluid rounded-start" alt="<?= $p['nama_mobil'] ?>">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title"><?= htmlspecialchars($p['nama_mobil']) ?></h5>
                                    <p class="mb-1">Nama: <?= htmlspecialchars($p['nama_pemesan']) ?></p>
                                    <p class="mb-1">No HP: <?= htmlspecialchars($p['no_hp']) ?></p>
                                    <p class="mb-1">Pesan: <?= htmlspecialchars($p['pesan']) ?></p>
                                    <p class="fw-bold text-primary">Rp <?= number_format($p['harga'], 0, ',', '.') ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning mt-4">Belum ada pesanan yang Anda buat.</div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
