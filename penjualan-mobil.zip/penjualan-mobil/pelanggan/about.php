<?php
session_start();
if (!isset($_SESSION['pelanggan'])) {
    header("Location: login.php");
    exit;
}
$pelanggan = $_SESSION['pelanggan'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tentang Kami - BETHCARZONE</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/dashboard-pelanggan.css"> <!-- Pastikan path ini benar -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .about-section {
            background: white;
            padding: 50px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="dashboard-pelanggan.php">BETHCARZONE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="dashboard-pelanggan.php">Beranda</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="daftar-mobil.php">Daftar Mobil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="#">Tentang</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="riwayat-pesanan.php">Riwayat</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- ✅ Konten About -->
<div class="container mt-5 mb-5">
    <div class="about-section">
        <h2 class="mb-4 text-primary">Tentang  BETHCARZONE</h2>
        <p>BETHCARZONE adalah platform jual-beli mobil terpercaya di Batam. Kami menyediakan berbagai pilihan mobil dari berbagai merek dan tahun yang siap untuk dimiliki. Website ini memudahkan pelanggan untuk melihat daftar mobil terbaru dan melakukan pemesanan dengan cepat.</p>
        <p>Dengan sistem pemesanan yang simpel dan tampilan yang user-friendly, BETHCARZONE hadir untuk memberikan kenyamanan dalam membeli mobil impian Anda. Kami juga menyediakan kontak showroom jika Anda ingin bertanya langsung atau melakukan test drive.</p>
        <hr>
        <p><strong>Alamat:</strong> Sagulung Sumber Mulia Blok D7 No 105, Batam</p>
        <p><strong>Email:</strong> info@bethcarzone.com</p>
        <p><strong>WhatsApp:</strong> <a href="https://wa.me/6281364068035" target="_blank">+62 813 6406 6035</a></p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>