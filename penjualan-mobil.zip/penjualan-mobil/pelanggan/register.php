<?php
include '../config/koneksi.php';
if (isset($_POST['register'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];

    $cek = mysqli_query($conn, "SELECT * FROM pelanggan WHERE email = '$email'");
    if (mysqli_num_rows($cek) > 0) {
        echo "<script>alert('Email sudah digunakan');</script>";
    } else {
        mysqli_query($conn, "INSERT INTO pelanggan (nama, email, password, no_hp, alamat) VALUES ('$nama', '$email', '$password', '$no_hp', '$alamat')");
        echo "<script>alert('Registrasi berhasil'); window.location='login.php';</script>";
    }
}
?>

<!-- Form Registrasi -->
<form method="post">
    <input type="text" name="nama" placeholder="Nama" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <input type="text" name="no_hp" placeholder="No HP" required><br>
    <textarea name="alamat" placeholder="Alamat"></textarea><br>
    <button name="register">Daftar</button>
</form>