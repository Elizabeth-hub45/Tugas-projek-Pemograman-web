<?php
include '../config/koneksi.php';
session_start();

if (!isset($_SESSION['pelanggan'])) {
    header("Location: login.php");
    exit;
}

$pelanggan = $_SESSION['pelanggan'];

// Tangkap kategori dari URL
$kategori = isset($_GET['kategori']) ? mysqli_real_escape_string($conn, $_GET['kategori']) : '';

// Query mobil berdasarkan kategori
$query = "SELECT * FROM mobil WHERE status = 'tersedia'";
if (!empty($kategori)) {
    $query .= " AND kategori = '$kategori'";
}
$query .= " ORDER BY tanggal_input DESC";

$mobil = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pelanggan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/dashboard-pelanggan.css"> <!-- Pastikan path ini benar -->
</head>
<body>

<!-- ✅ Navbar Pelanggan -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="dashboard-pelanggan.php">BETHCARZONE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active" href="dashboard-pelanggan.php">Beranda</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="daftar-mobil.php">Daftar Mobil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">Tentang</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="riwayat-pesanan.php">Riwayat</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- ✅ Konten -->
<div class="container mt-4">

    <!-- Hero -->
    <div class="hero mb-5 text-center">
        <h1>Halo, <?= htmlspecialchars($pelanggan['nama']) ?>! 👋</h1>
        <p class="lead">Selamat datang di BethCarZone! Silakan jelajahi mobil pilihan kami dan informasi showroom.</p>
    </div>

    <!-- 3 Mobil Terbaru -->
    <h3 class="mb-4">🚗 Mobil Terbaru</h3>
    <div class="row g-4 mb-5">
        <?php
        $mobil = mysqli_query($conn, "SELECT * FROM mobil WHERE status = 'tersedia' ORDER BY tanggal_input DESC LIMIT 3");
        while ($m = mysqli_fetch_assoc($mobil)) {
        ?>
        <div class="col-md-4">
            <div class="card shadow-sm h-100">
                <img src="../img/<?= $m['gambar'] ?>" class="card-img-top mobil-img" alt="<?= htmlspecialchars($m['nama_mobil']) ?>">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?= htmlspecialchars($m['nama_mobil']) ?></h5>
                    <p class="text-muted mb-1"><?= $m['merk'] ?> • <?= $m['tahun'] ?></p>
                    <p class="mb-2"><?= substr($m['deskripsi'], 0, 60) ?>...</p>
                    <p class="fw-bold text-primary mb-3">Rp <?= number_format($m['harga'], 0, ',', '.') ?></p>
                    <a href="../form-pesanan.php?id=<?= $m['id_mobil'] ?>" class="btn btn-success mt-auto w-100">Pesan Sekarang</a>
                    <a href="detail_mobil.php?id=<?= $m['id_mobil'] ?>" class="btn btn-secondary mt-2 w-100">Detail Mobil</a>
                </div>
            </div>
        </div>
        <?php } ?>
        <?php if (mysqli_num_rows($mobil) == 0): ?>
        <div class="col-12">
            <div class="alert alert-warning">Belum ada mobil tersedia saat ini.</div>
        </div>
        <?php endif; ?>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
