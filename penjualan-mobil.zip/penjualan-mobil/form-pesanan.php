<?php
include 'config/koneksi.php';

if (!isset($_GET['id'])) {
    header("Location: riwayat-pesanan.php");
    exit;
}

$id_mobil = $_GET['id'];
$mobil = mysqli_query($conn, "SELECT * FROM mobil WHERE id_mobil = '$id_mobil'");
$data = mysqli_fetch_assoc($mobil);

if (!$data) {
    echo "<h4>Mobil tidak ditemukan</h4>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama_pemesan'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    $pesan = $_POST['pesan'];
    $metode = $_POST['metode_pembayaran'];

    mysqli_query($conn, "INSERT INTO pesanan (id_mobil, nama_pemesan, email, no_hp, pesan, metode_pembayaran) 
                         VALUES ('$id_mobil', '$nama', '$email', '$no_hp', '$pesan', '$metode')");

    echo "<script>alert('Pesanan berhasil dikirim!'); window.location='sukses.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Form Pesan Mobil</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    
</head>
<body class="container mt-5">
    <h2>Form Pemesanan: <?= htmlspecialchars($data['nama_mobil']) ?></h2>

    <form method="POST">
        <div class="mb-3">
            <label>Nama Lengkap</label>
            <input type="text" name="nama_pemesan" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>No HP</label>
            <input type="text" name="no_hp" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Pesan / Catatan</label>
            <textarea name="pesan" class="form-control"></textarea>
        </div>
        <div class="mb-3">
            <label>Metode Pembayaran</label>
            <select name="metode_pembayaran" class="form-select" required>
                <option value="Cash">Cash</option>
                <option value="Transfer">Transfer</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Kirim Pesanan</button>
        <a href="riwayat-pesanan.php" class="btn btn-secondary">Kembali</a>
    </form>
</body>
</html>
