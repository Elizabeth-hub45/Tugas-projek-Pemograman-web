<!DOCTYPE html>
<html>
<head>
    <title>Pesanan Sukses</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5 text-center">
    <h2 class="text-success">🎉 Pesanan Anda Berhasil Dikirim!</h2>
    <p class="mt-3">Terima kasih telah memesan mobil di MobilStore. Tim kami akan segera menghubungi Anda.</p>
    <a href="pelanggan/dashboard-pelanggan.php" class="btn btn-primary mt-3">Kembali ke Beranda</a>
</body>
</html>
