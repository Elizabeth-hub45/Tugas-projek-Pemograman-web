const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const db = require('./db'); // Anggap ini adalah koneksi ke database Anda

router.post('/ubah-password', async (req, res) => {
  const { passwordLama, passwordBaru, konfirmasiPasswordBaru } = req.body;
  const userId = req.session.userId; // Ambil ID pengguna dari sesi

  // Validasi dasar
  if (!passwordLama || !passwordBaru || !konfirmasiPasswordBaru) {
    return res.status(400).json({ message: 'Semua field harus diisi.' });
  }

  if (passwordBaru !== konfirmasiPasswordBaru) {
    return res.status(400).json({ message: 'Password baru dan konfirmasi tidak cocok.' });
  }

  try {
    // 1. Ambil data pengguna dari database
    const user = await db.query('SELECT password FROM users WHERE id = $1', [userId]);
    if (user.rows.length === 0) {
      return res.status(404).json({ message: 'Pengguna tidak ditemukan.' });
    }

    // 2. Verifikasi password lama
    const passwordCocok = await bcrypt.compare(passwordLama, user.rows[0].password);
    if (!passwordCocok) {
      return res.status(401).json({ message: 'Password lama salah.' });
    }

    // 3. Hash password baru
    const salt = await bcrypt.genSalt(10);
    const hashedPasswordBaru = await bcrypt.hash(passwordBaru, salt);

    // 4. Update password di database
    await db.query('UPDATE users SET password = $1 WHERE id = $2', [hashedPasswordBaru, userId]);

    // 5. Kirim respons sukses
    res.status(200).json({ message: 'Password berhasil diubah.' });

    // 6. (Opsional) Invalidasi sesi
    // req.session.destroy();

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Terjadi kesalahan server.' });
  }
});

module.exports = router;
