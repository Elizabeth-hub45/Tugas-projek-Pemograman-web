-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Jul 2025 pada 07.40
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jual_mobil`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(3, 'admin', '$2y$10$omS9vsH2YR/i3Uae1LfIZOH6b97CVAeEMZYdEYxxjLRsJamahD6Ey');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(4, 'Sedan'),
(5, 'Hatcback'),
(6, 'SUV (Sport Utility Vehicle)'),
(7, 'MPV (Multi-Purpose Vehicle'),
(8, 'Crossover'),
(9, 'Pick-up'),
(10, 'Convertible'),
(11, 'wagon'),
(12, 'van/Minibus');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mobil`
--

CREATE TABLE `mobil` (
  `id_mobil` int(11) NOT NULL,
  `nama_mobil` varchar(100) DEFAULT NULL,
  `merk` varchar(50) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `tahun` int(11) DEFAULT NULL,
  `harga` bigint(20) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `status` enum('tersedia','terjual') DEFAULT 'tersedia',
  `tanggal_input` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `mobil`
--

INSERT INTO `mobil` (`id_mobil`, `nama_mobil`, `merk`, `id_kategori`, `tahun`, `harga`, `deskripsi`, `gambar`, `status`, `tanggal_input`) VALUES
(2, 'Abarth 124 Spider series 2', 'Abarth', NULL, 2020, 477000000, 'Deskripsi Umum:\r\nAbarth 124 Spider adalah mobil sport dua kursi bergaya roadster yang menggabungkan kecepatan, gaya, dan sensasi berkendara terbuka. Dikembangkan oleh Abarth – divisi performa dari Fiat – mobil ini menghadirkan pengalaman mengemudi yang dinamis dengan desain khas Italia dan sentuhan agresif.\r\n\r\n\r\nSpesifik Singkat: \r\nMesin: 1.4L Turbo MultiAir, 4 silinder\r\n\r\nTenaga Maksimum: 170 HP @ 5.500 rpm\r\n\r\nTorsi: 250 Nm @ 2.500 rpm\r\n\r\nTransmisi: Manual 6-percepatan / Otomatis 6-percepatan\r\n\r\nPenggerak: Rear-Wheel Drive (RWD)\r\n\r\n0–100 km/jam: Sekitar 6,8 detik\r\n\r\nTop Speed: 232 km/jam\r\n\r\nKapasitas Tangki: 45 liter\r\n\r\nBerat Kosong: ±1.060 kg\r\n\r\nFitur Unggulan: \r\nSuspensi sport dari Bilstein\r\n\r\nRem Brembo untuk pengereman presisi\r\n\r\nKnalpot Record Monza dengan suara khas Abarth\r\n\r\nMode berkendara Sport\r\n\r\nInterior berbahan Alcantara dan kulit\r\n\r\nSoft-top convertible (buka tutup manual)\r\n\r\nVelg racing 17 inci', 'Abarth 124 Spider serie 2 (348) anni 2016-2019_ scheda tecnica e listino usato.jpg', 'tersedia', '2025-06-29 07:19:50'),
(3, 'Abarth 500 Gets Alpha N ', 'Abarth', NULL, 2019, 230000000, 'Spesifikasi Dasar Abarth 500 (2008–2015)\r\nMesin: 1.4 L turbocharged T‑Jet / MultiAir, 4 silinder (1368 cc)\r\n\r\nTenaga: 135 hp @5500 rpm (standar); 160 hp pada versi Esseesse \r\nyourcar360.com\r\nautomobilesreview.com\r\n+1\r\ncarscoops.com\r\n+1\r\n\r\nTorsi: 206–230 Nm tergantung mode & versi\r\n\r\nTransmisi: Manual 5‑percepatan (adapula otomatis MTA)\r\n\r\nPenggerak: FWD\r\n\r\nPerforma:\r\n\r\n0–100 km/jam: 7,9 detik (500), 7,4 detik (Esseesse)\r\nTop speed: ~205 km/jam\r\n\r\nDimensi:\r\n\r\nPanjang 3657 mm × Lebar 1627 mm × Tinggi ~1485 mm; wheelbase 2300 mm \r\nautomobilesreview.com\r\n+2\r\nengineindetail.com\r\n+2\r\nyourcar360.com\r\n+2\r\n\r\nBerat: 1035–1110 kg \r\nmarketwatch.com\r\n+9\r\nautomobilesreview.com\r\n+9\r\nyourcar360.com\r\n+9\r\n\r\nKonsumsi/Bahan Bakar:\r\n\r\nCombined ~6,5 l/100 km, CO₂ ~155 g/km \r\ncarscoops.com\r\n+14\r\nengineindetail.com\r\n+14\r\nautomobilesreview.com\r\n+14\r\n\r\n🎯 Fitur Unggulan & Karakter\r\nPengaturan suspensi & knalpot sport bawaan pabrik\r\n\r\nSistem Torque Transfer Control (TTC) untuk mengurangi understeer \r\nit.wikipedia.org\r\n\r\nKnalpot record Monza dan interior sporty dengan trim kulit/Alcantara (bervariasi per model)\r\n\r\nVelg 16–17″, rem Brembo (khusus varian tinggi), dan aksen sporty Abarth', 'Abarth 500 Gets Alpha N Performance Goodies _ Carscoops.jpg', 'tersedia', '2025-06-29 07:23:44'),
(4, 'Abarth 695 Tributo Ferari ', 'Abarth', NULL, 2021, 800000000, 'Spesifikasi Utama\r\nTenaga: 180 PS (≈177 HP) @ 5.500 rpm\r\n\r\nTorsi: 250 Nm @ 3.000 rpm \r\nsupercars.net\r\n+15\r\nautoevolution.com\r\n+15\r\niotomotif.com\r\n+15\r\nes.wikipedia.org\r\n+2\r\npistonheads.com\r\n+2\r\nsimonfurlonger.co.uk\r\n+2\r\niotomotif.com\r\nhobbyexpressinc.com\r\n+3\r\nen.wikipedia.org\r\n+3\r\notosia.com\r\n+3\r\n\r\nTransmisi: 5‑speed otomatis F1‑style paddle (MTA) \r\notosia.com\r\n\r\nAkselerasi: 0–100 km/j ≤ 7 detik \r\niotomotif.com\r\n+2\r\notosia.com\r\n+2\r\noto.detik.com\r\n+2\r\n\r\nTop Speed: ~225 km/j (140 mph) \r\notosia.com\r\n+13\r\nfastestlaps.com\r\n+13\r\nsupercars.net\r\n+13\r\n\r\nBerat: ~1.130–1.143 kg\r\n\r\n🌟 Fitur Eksklusif & Desain\r\nEdisi terbatas: 1.696 unit global \r\noto.detik.com\r\n+3\r\notosia.com\r\n+3\r\niotomotif.com\r\n+3\r\n\r\nWarna: Rosso Corsa (1.199), Giallo Modena, Grigio Titanio, Blu Abu Dhabi \r\noto.detik.com\r\n+14\r\nit.wikipedia.org\r\n+14\r\nes.wikipedia.org\r\n+14\r\n\r\nEksterior:\r\n\r\nDual stripes silver seperti Ferrari F430 Scuderia\r\n\r\nSpion & pilar B berbahan karbon\r\n\r\nVelg 17″ ala Ferrari 599/360 \r\nit.wikipedia.org\r\n+1\r\notosia.com\r\n+1\r\notosia.com\r\n+1\r\niotomotif.com\r\n+1\r\n\r\nInterior:\r\n\r\nCarbon fiber trim\r\n\r\nSetir kulit & paddle shift\r\n\r\nBucket seats “Abarth Corsa by Sabelt”\r\n\r\nInstrument panel terinspirasi Ferrari\r\n\r\nDetail kaki‑kaki aluminium & pedal Scorpion \r\nautoblog.com\r\n+13\r\nen.wikipedia.org\r\n+13\r\nit.wikipedia.org\r\n+13\r\notosia.com\r\n+1\r\nsupercars.net\r\n+1\r\n\r\nRangkaian performa:\r\n\r\nRem Brembo 4-piston (284 mm)\r\n\r\nSuspensi sport, ESP & Torque Transfer Control (TTC) \r\nen.wikipedia.org\r\n+3\r\notosia.com\r\n+3\r\nsupercars.net\r\n+3\r\ncarsguide.com.au\r\n+2\r\nautoevolution.com\r\n+2\r\ncarsession.com\r\n+2\r\n\r\nKnalpot “Record Monza” dual-mode', 'ABARTH 695 TRIBUTO FERRARI TRIBUTO AL GIAPPONE｜コンパクトスポーツカー ABARTH(アバルト).jpg', 'tersedia', '2025-06-29 07:27:35'),
(5, 'Fiat 600 3Abarth ', 'Abarth', NULL, 2025, 800000000, ' Roadster / Convertible Sport Car\r\n\r\nPenjelasan:\r\n\r\nRoadster: mobil sport dua pintu, dua kursi, dan atap terbuka (convertible soft top).\r\n\r\nConvertible: atapnya bisa dibuka-tutup (biasanya secara manual atau elektrik).\r\n\r\nSport Car: performa tinggi, handling lincah, dan desain aerodinamis.\r\n\r\n✅ Kategori Resmi (seperti di STNK Indonesia):\r\nBiasanya dikategorikan sebagai:\r\n➡️ Sedan (karena mobil kecil, atap rendah, bukan SUV/MPV)\r\natau\r\n➡️ Mobil Sport / Sport Car (jika ada klasifikasi khusus berdasarkan tipe kendaraan)\r\n\r\n🔧 Spesifikasi Pendukung:\r\nMesin: 1.4L Turbo MultiAir (170 HP)\r\n\r\nKursi: 2 penumpang\r\n\r\nTransmisi: Manual / Otomatis\r\n\r\nBodi: Convertible (atap bisa dibuka)\r\n\r\nPenggerak: RWD (Rear Wheel Drive)', 'Fiat 600e Abarth (2025).jpg', 'tersedia', '2025-06-29 07:29:34'),
(6, 'Test Abarth 595c ', 'Abarth', NULL, 2023, 508000000, 'Mesin & Performa\r\nMesin 1.4 L turbo: varian awal 140 PS, top-tier Competizione/Scorpion hingga 180 ps \r\nleredacteurauto.be\r\n+1\r\ncarwow.co.uk\r\n+1\r\neurekar.co.uk\r\n+2\r\nmotor1.com\r\n+2\r\ntopgear.com\r\n+2\r\n\r\nTorsi sekitar 230–250 Nm\r\n\r\nAkselerasi 0–100 km/jam:\r\n\r\nStandard/manual ~8,1 detik\r\n\r\nTurismo ~7,3 detik\r\n\r\nCompetizione ~6,7 detik \r\nmotor1.com\r\n+5\r\nhonestjohn.co.uk\r\n+5\r\nautoevolution.com\r\n+5\r\njordantimes.com\r\n+4\r\ncarbuyer.co.uk\r\n+4\r\ntorquingcars.com\r\n+4\r\n\r\nTop Speed: ~225 km/jam (~140 mph)', 'Test Abarth 595C Competizione – ein liebenswerter Rabauke.jpg', 'tersedia', '2025-06-29 07:31:49'),
(7, 'Acura MDX', 'Acura', NULL, 2022, 834000000, 'pesifikasi Umum (2022–2025)\r\nSpesifikasi	Keterangan\r\nMesin	3.5L V6 i-VTEC, 290 HP (standar)\r\nTransmisi	10-speed automatic\r\nPenggerak	FWD / AWD (SH-AWD)\r\nVarian Tertinggi	Type S: 3.0L Turbo V6, 355 HP\r\nTempat Duduk	3 baris (7 penumpang)\r\nInterior	Kulit premium, panoramic roof, ambient lighting\r\nInfotainment	Layar 12.3”, ELS Studio Audio, Apple CarPlay, Android Auto\r\nFitur Safety	AcuraWatch (ADAS): Adaptive Cruise, Lane Assist, Collision Braking\r\n\r\n\r\n', '2022 Acura MDX.jpg', 'tersedia', '2025-06-29 07:36:12'),
(8, 'Acura TLX Facelift', 'Acura', NULL, 2025, 844560000, 'Acura TLX Facelift 2025 adalah sedan mewah sport berukuran menengah yang tampil lebih agresif, canggih, dan nyaman. Mengusung desain premium khas Acura, mobil ini dirancang untuk menyatukan performa tinggi dengan teknologi modern dan kenyamanan khas mobil eksekutif.\r\n\r\n🔷 Eksterior\r\nDesain luar TLX facelift menampilkan bahasa desain baru Acura:\r\n\r\nGril depan Diamond Pentagon model frameless yang lebih tajam dan elegan.\r\n\r\nLampu depan LED Jewel Eye yang tajam dengan lampu DRL berbentuk strip.\r\n\r\nVelg sporty berukuran 19–20 inci, tergantung varian.\r\n\r\nTersedia warna baru seperti Urban Gray Pearl dan Liquid Carbon Metallic.\r\n\r\nDesain keseluruhan lebih rendah dan lebar, memberi kesan sporty dan dinamis.\r\n\r\n🔶 Interior\r\nKabinnya memadukan kemewahan dan teknologi tinggi:\r\n\r\nLayar digital 12,3 inci (Precision Cockpit) dan infotainment layar lebar 12,3 inci.\r\n\r\nTersedia head-up display 10,5 inci, hanya di varian A-Spec & Type S.\r\n\r\nMaterial interior berkualitas tinggi: kombinasi kulit premium, aluminium, dan Alcantara.\r\n\r\nSistem audio premium ELS Studio (13 atau 17 speaker tergantung varian).\r\n\r\nFitur kenyamanan lengkap: kursi berpemanas & ventilasi, pencahayaan ambient, wireless charger, dan integrasi Android Auto & Apple CarPlay nirkabel.\r\n\r\n🛡️ Fitur Keselamatan & Bantuan Mengemudi\r\nDilengkapi paket AcuraWatch 360+, termasuk:\r\n\r\nKamera 360°\r\n\r\nBlind Spot Information (BSI)\r\n\r\nAdaptive Cruise Control\r\n\r\nLane Keep Assist & Collision Mitigation Braking System\r\n\r\nRear Cross Traffic Monitor\r\n\r\nSistem radar baru 120° dan kamera definisi tinggi.\r\n\r\nNotifikasi sabuk pengaman untuk penumpang belakang (fitur baru 2025).\r\n\r\n⚙️ Performa & Mesin\r\nVarian Technology & A-Spec:\r\n\r\nMesin 2.0L Turbo 4-silinder, 272 hp, torsi 380 Nm.\r\n\r\nTransmisi otomatis 10 percepatan.\r\n\r\nPenggerak roda depan (FWD) atau SH-AWD (untuk A-Spec).\r\n\r\nVarian Type S:\r\n\r\nMesin 3.0L Turbo V6, 355 hp, torsi 480 Nm.\r\n\r\nSistem penggerak semua roda Super Handling All-Wheel Drive (SH-AWD).\r\n\r\nSuspensi adaptif dan rem Brembo.\r\n\r\nDirancang untuk pengalaman berkendara performa tinggi namun tetap nyaman.', '2024 Acura TLX Facelift Is Almost Too Subtle To Notice.jpg', 'tersedia', '2025-06-29 13:00:46'),
(9, 'Acura ZDX', 'Acura', NULL, 2024, 1206135000, 'Berikut ulasan lengkap mengenai Acura ZDX (2024–2025) — crossover mewah listrik pertama dari Acura:\r\n\r\n⚡ Platform & Model\r\nZDX adalah SUV listrik ukuran menengah yang dibangun di atas GM Ultium platform, berbagi arsitektur dengan Cadillac Lyriq dan Chevrolet Blazer EV \r\ntopspeed.com\r\n+11\r\nen.wikipedia.org\r\n+11\r\nedmunds.com\r\n+11\r\n.\r\n\r\nResmi diperkenalkan pada Agustus 2023 sebagai model 2024, dan tersedia hingga model 2025–2026 tanpa perubahan signifikan .\r\n\r\n🔋 Varian & Spesifikasi\r\nTerdapat tiga trim utama:\r\n\r\nZDX A‑Spec RWD\r\n\r\nMotor tunggal, penggerak roda belakang (RWD), tenaga ≈ 358–342 hp\r\n\r\nBaterai 102 kWh\r\n\r\nEst. jarak tempuh hingga ~313–325 mil (≈ 503–523 km) \r\nevsaaz.com\r\n+9\r\nen.wikipedia.org\r\n+9\r\nrizzaacura.com\r\n+9\r\nrizzaacura.com\r\n\r\nAkselerasi 0–60 mph ≈ 5–5.5 detik \r\ntheverge.com\r\n+9\r\nacuraoferie.com\r\n+9\r\nedmunds.com\r\n+9\r\n\r\nZDX A‑Spec AWD\r\n\r\nDual motor (AWD), tenaga ≈ 490 hp\r\n\r\nEst. jarak ~304 mil (≈ 489 km) \r\ntopspeed.com\r\n+12\r\nedmunds.com\r\n+12\r\nrizzaacura.com\r\n+12\r\nchicagoautoshow.com\r\n+2\r\ntxgarage.com\r\n+2\r\nde.wikipedia.org\r\n+2\r\n\r\nZDX Type S AWD\r\n\r\nDual motor AWD, tenaga ≈ 499–500 hp, torsi ≈ 738–544 lb‑ft\r\n\r\nSuspensi udara adaptif, rem Brembo, roda 22″ \r\nde.wikipedia.org\r\n+13\r\nen.wikipedia.org\r\n+13\r\ntxgarage.com\r\n+13\r\n\r\nJarak tempuh ~278 mil (~447 km), 0–60 mph ≈ 4 detik \r\ntheverge.com\r\n+5\r\ntxgarage.com\r\n+5\r\nen.wikipedia.org\r\n+5\r\n\r\n🔧 Performa & Pengisian\r\nDC fast charging hingga 190 kW: dapat menambah ~81 mil jarak dalam 10 menit, atau 20–80 % dalam ~30–42 menit \r\ntxgarage.com\r\n+5\r\nmotor1.com\r\n+5\r\nen.wikipedia.org\r\n+5\r\n.\r\n\r\nTowing capacity hingga ~3.500 lb \r\nautoblog.com\r\n+14\r\nwsj.com\r\n+14\r\nevsaaz.com\r\n+14\r\n.\r\n\r\n🛋️ Interior & Teknologi\r\nKabin premium dengan desain minimalis: dual layar digital (11″ instrumen, 11.3″ infotainment), Google Android Automotive, Google Maps, Apple CarPlay dan Android Auto nirkabel \r\nwsj.com\r\n+7\r\nsuggestionscar.com\r\n+7\r\ntheverge.com\r\n+7\r\n.\r\n\r\nAudio Bang & Olufsen 18-speaker, opsi Beosonic audio moods (Bright, Energetic, Warm, Relaxed) \r\ncaranddriver.com\r\n+6\r\nrizzaacura.com\r\n+6\r\nsuggestionscar.com\r\n+6\r\n.\r\n\r\nFitur kelas atas: panoramic roof, kursi ventilasi/pemanas dengan pijat, head-up display, steering kolom dapat disetel elektrik, wireless charger .\r\n\r\n🛡️ Keselamatan & Driver Assist\r\nStandar AcuraWatch™: adaptive/cruise, Lane Keep, blind‑spot, rear‑cross traffic, automatic parking assist, surround camera, dan hands‑free driving (Super Cruise / Hands Free Cruise di Type S) \r\nchicagoautoshow.com\r\n+2\r\nautoblog.com\r\n+2\r\nrizzaacura.com\r\n+2\r\n.\r\n\r\n💵 Harga & Pesaing\r\nHarga AS (MSRP):\r\n\r\nA‑Spec RWD ≈ US $64.5k\r\n\r\nA‑Spec AWD ≈ US $68.5k\r\n\r\nType S AWD ≈ US $73.5–74.5k \r\nedmunds.com\r\n+9\r\ntxgarage.com\r\n+9\r\nchicagoautoshow.com\r\n+9\r\n\r\nEstimasi harga di Indonesia: mulai sekitar Rp 975 juta hingga Rp 1,06 miliar \r\nevsaaz.com\r\n.\r\n\r\nSaingan utama: BMW iX, Cadillac Lyriq, Tesla Model X, Genesis GV60, Kia EV6 GT \r\nwsj.com\r\n+3\r\nchicagoautoshow.com\r\n+3\r\nedmunds.com\r\n+3\r\n.\r\n\r\n✅ Ringkasan\r\nAcura ZDX mewakili langkah awal Acura di era EV mewah. Kelebihannya meliputi:\r\n\r\nPilihan varian dari luxury (A‑Spec RWD) hingga performa tinggi (Type S AWD)\r\n\r\nDesain eksterior modern, kabin digital premium\r\n\r\nFitur pengisian cepat dan teknologi berkendara canggih\r\n\r\nHarga kompetitif, walau sedikit lebih tinggi dibanding homolog GM\r\n\r\nKendati ada kritik soal “badge-engineering” GM (fitur sama dengan Lyriq/blazer EV) \r\nautoblog.com\r\n+12\r\nwsj.com\r\n+12\r\ntxgarage.com\r\n+12\r\ntxgarage.com\r\n+1\r\nchicagoautoshow.com\r\n+1\r\n, ZDX masih menarik untuk pebisnis dan keluarga muda yang ingin mobil listrik premium, bergaya, dan bertenaga.\r\n\r\n', '2024 Acura ZDX Type S First Drive Review_ A Good Car With First-EV Jitters.jpg', 'tersedia', '2025-06-29 13:05:14'),
(10, 'Acura ILX', 'Acura', NULL, 2016, 445100000, ' Ringkasan Model & Status\r\nAcura ILX adalah sedan kompak mewah (compact executive/D‑segment), diproduksi dari 2012 hingga 2022, berbasis Honda Civic generasi ke-9 atau ke-10 \r\nreddit.com\r\n+15\r\nen.wikipedia.org\r\n+15\r\nauto-data.net\r\n+15\r\n.\r\n\r\nILX telah dihentikan setelah model 2022, digantikan oleh Acura Integra \r\nreddit.com\r\n+1\r\nautogiz.com\r\n+1\r\n.\r\n\r\n⚙️ Spesifikasi Teknis (2016–2022 facelift)\r\nMesin: 2.4 L i‑VTEC I4, 201 hp @ 6.800 rpm, torsi 180 lb‑ft @ 3.600 rpm \r\ncarsdirect.com\r\n+6\r\nautoevolution.com\r\n+6\r\ncopilotsearch.com\r\n+6\r\n.\r\n\r\nTransmisi: 8‑speed dual-clutch automatic (DCT); penggerak roda depan \r\nautoshall.com\r\n+15\r\nen.wikipedia.org\r\n+15\r\nautoevolution.com\r\n+15\r\n.\r\n\r\nAkselerasi 0‑100 km/jam: sekitar 6.4–6.6 detik \r\nreddit.com\r\n+4\r\nreleasedatesautos.com\r\n+4\r\nen.wikipedia.org\r\n+4\r\n.\r\n\r\nDimensi: panjang ~4,628 mm, wheelbase 2,670 mm, bagasi 348 L \r\nauto-data.net\r\n.\r\n\r\nKonsumsi BBM (EPA): ±24 mpg (9.8 L/100 km) kota, 34 mpg (6.9 L/100 km) tol \r\nautoevolution.com\r\n+1\r\nreddit.com\r\n+1\r\n.\r\n\r\n🛋️ Fitur Interior & Kenyamanan\r\nKursi depan 8/17‑way power dengan pendingin/pemanas pada versi Premium dan A‑Spec \r\nautogiz.com\r\n+7\r\ncars.usnews.com\r\n+7\r\nreleasedatesautos.com\r\n+7\r\n.\r\n\r\nInfotainment dual‑screen (7″ + 8″) tersedia pada versi Premium/Technology, mendukung Apple CarPlay & Android Auto \r\nautoshall.com\r\n+4\r\ncopilotsearch.com\r\n+4\r\nen.wikipedia.org\r\n+4\r\n.\r\n\r\nSistem audio hingga 10-speaker ELS Studio pada paket Technology \r\nreleasedatesautos.com\r\n+2\r\nautoevolution.com\r\n+2\r\ncarsdirect.com\r\n+2\r\n.\r\n\r\nSunroof, dual-zone climate control, keyless entry, dan bahan jok kulit tersedia pada trim atas \r\nen.wikipedia.org\r\n+7\r\ncars.usnews.com\r\n+7\r\ncarsdirect.com\r\n+7\r\n.\r\n\r\n🛡️ Keselamatan & Bantuan Mengemudi\r\nAcuraWatch™: termasuk fitur seperti adaptive cruise control, lane‑keep assist, collision mitigation braking system, blind‑spot monitoring, rear cross‑traffic alert pada paket Premium/Technology \r\nmotowheeler.com\r\n+5\r\nautoevolution.com\r\n+5\r\ncopilotsearch.com\r\n+5\r\n.\r\n\r\nMendapat rating 5‑star dari NHTSA', 'First Drive_ 2016 Acura ILX.jpg', 'tersedia', '2025-06-29 13:07:20'),
(11, 'Avura RDX', 'Acura', NULL, 2025, 445100000, ' Mesin & Performa\r\nMesin 2.0 L turbocharged I4 menghasilkan 272 hp dan 280 lb‑ft torsi, dipadukan transmisi otomatis 10‑percepatan. Semua varian dilengkapi sistem AWD dengan teknologi Super Handling AWD (SH‑AWD) \r\ncaranddriver.com\r\n+12\r\ncars.com\r\n+12\r\nnewcars.com\r\n+12\r\n.\r\n\r\nHasil pengujian menunjukkan akselerasi 0–60 mph ≈ 6,4–6,7 detik \r\nmotortrend.com\r\n.\r\n\r\n🔋 Konsumsi & Efisiensi\r\nPerforma bahan bakar EPA: 21 mpg dalam kota / 27 mpg tol / 23 mpg kombinasi; A‑Spec sedikit berbeda tol 26 mpg \r\nacura.com\r\n+6\r\ncars.com\r\n+6\r\ncargurus.com\r\n+6\r\n.\r\n\r\n🎨 Eksterior\r\nGril “Diamond Pentagon” tanpa bingkai dan lampu depan Jewel‑Eye LED; desain lebih tegas untuk model 2025 \r\ncarpro.com\r\n.\r\n\r\nPilihan velg standar 19″, A‑Spec dengan 20″ Shark Grey wheel, Advance dan A‑Spec Advance dengan velg 20″ Berlina Black–finish \r\ncargurus.com\r\n+11\r\ncars.com\r\n+11\r\nacura.com\r\n+11\r\n.\r\n\r\nTersedia warna baru: Urban Gray Pearl, Canyon River Blue Metallic, Solar Silver Metallic, dan Performance Red Pearl \r\ncarsdirect.com\r\n+7\r\nacura.com\r\n+7\r\nacura.com\r\n+7\r\n.\r\n\r\n🛋️ Interior & Kenyamanan\r\nLayar infotainment 10.2″ dengan True Touchpad Interface, Apple CarPlay & Android Auto nirkabel layar penuh \r\nacura.com\r\n+1\r\nen.wikipedia.org\r\n+1\r\n.\r\n\r\nKonsol tengah ditata ulang, cupholder lebih besar, dan wireless charger yang lebih mudah dijangkau .\r\n\r\nKabin dilengkapi ambient lighting (27 tema), panoramic sunroof, serta kursi depan synthetic leather berpemanas/berdaya \r\nacura.com\r\n+2\r\ntruecar.com\r\n+2\r\ncarsdirect.com\r\n+2\r\n.\r\n\r\nPada trim Advance & A-Spec Advance: kursi ventilasi, head-up display, Surround‑View Camera, heated steering wheel, dan trim kayu terbuka \r\nmotortrend.com\r\n+11\r\nacura.com\r\n+11\r\ntruecar.com\r\n+11\r\n.\r\n\r\n🛡️ Keselamatan & Teknologi\r\nPaket lengkap AcuraWatch™ mencakup adaptive cruise, lane keep/steer, collision mitigation, blind-spot & rear cross traffic alerts, auto high beams & traffic-sign recognition \r\nacura.com\r\n+5\r\ncars.com\r\n+5\r\nnewcars.com\r\n+5\r\n.\r\n\r\nMendapat rating keselamatan IIHS Top Safety Pick dan 5-bintang NHTSA ', 'Understated Acura RDX one to watch.jpg', 'tersedia', '2025-06-29 13:09:03'),
(12, 'Aion GAC-V', 'Aion', NULL, 2024, 537000000, 'Kategori Mobil\r\nSUV Kompak (Compact SUV)\r\nUkurannya lebih kecil dari SUV besar, mudah dikendarai di kota, namun tetap lapang dan fungsional untuk keluarga.\r\n\r\n100 % Battery Electric Vehicle (BEV)\r\nKendaraan bertenaga sepenuhnya listrik, tanpa mesin pembakaran internal.\r\n\r\n⚡ Ringkasan Spesifikasi & Fitur\r\nDimensi (generasi 2 sejak 2024): panjang ~4,605 mm, lebar ~1,854–1,876 mm, tinggi ~1,660–1,686 mm, wheelbase ~2,775 mm \r\ngacgroup.com\r\n+2\r\nen.wikipedia.org\r\n+2\r\nthesun.co.uk\r\n+2\r\nreuters.com\r\n+10\r\ncarnewschina.com\r\n+10\r\nreddit.com\r\n+10\r\nmycarforum.com\r\n\r\nTipe motor & baterai: motor depan (FWD) 165 kW (~224 hp), torsi 240 Nm; baterai LFP tersedia 62.7 / 75.3 / 90.2 kWh, jarak WLTP/CLTC hingga 750 km \r\nmycarforum.com\r\n+2\r\nde.wikipedia.org\r\n+2\r\ncarnewschina.com\r\n+2\r\n\r\nFast-charging: teknologi ultra-cepat hingga 480 kW (80 % dalam 15–16 menit) \r\nen.wikipedia.org\r\n+1\r\nreddit.com\r\n+1\r\n\r\nInterior & teknologi canggih: layar instrumen + infotainment besar (~14.6″), ADiGO 5.0 + sistem piloting AI dengan lidar & radar, banyak gadget seperti kulkas 6.6 L, wireless charger ganda, ambient lighting, V2L 3.3 kW \r\nthesun.co.uk\r\n+4\r\ncarnewschina.com\r\n+4\r\nmycarforum.com\r\n+4\r\n\r\nKeselamatan & ADAS Level 2: Surround-view camera, 11–12 sensor, adaptive cruise, lane-keeping, dan kemampuan L4 di Tiongkok (kerjasama Didi)\r\n\r\n', '2024 GAC Motor Aion V - Stunning HD Photos, Videos, Specs, Features & Price - DailyRevs.jpg', 'tersedia', '2025-06-29 13:11:31'),
(13, 'Aion S_ Greesn Innovation on Wheels', 'Aion', NULL, 2024, 498000000, 'GAC Aion S “Green Innovation on Wheels” adalah sedan listrik kompak premium dari GAC Aion yang mengedepankan inovasi ramah lingkungan & teknologi smart manufacturing.\r\n\r\n🔌 Kategori Mobil\r\nCompact Executive EV Sedan — mobil listrik kelas menengah dengan dimensi dan performa sekelas sedan premium \r\nhezhongcars.com\r\n+3\r\nen.wikipedia.org\r\n+3\r\ngacgroup.com\r\n+3\r\n.\r\n\r\n⚙️ Spesifikasi & Performa\r\nMotor Listrik FWD: pilihan motor 100 kW (~136 hp) atau 135 kW (~184 hp), torsi hingga 300 Nm \r\nde.wikipedia.org\r\n.\r\n\r\nBaterai LFP & NCM (45–60 kWh), jarak tempuh CLTC 420–510 km \r\nde.wikipedia.org\r\n+3\r\nen.wikipedia.org\r\n+3\r\naionindonesia.com\r\n+3\r\n.\r\n\r\nAkselerasi: 0–100 km/j ≈ 6,7–7,9 detik \r\naionev.my.id\r\n+1\r\naionindonesia.com\r\n+1\r\n.\r\n\r\nAerodinamika baik (Cd ~0,245; Aion S Plus ~0,211) yang mendukung efisiensi \r\nhongjiauto.com\r\n+11\r\nichelabamotor.en.made-in-china.com\r\n+11\r\nde.wikipedia.org\r\n+11\r\n.\r\n\r\n🧩 Dimensi & Fasilitas\r\nPanjang × Lebar × Tinggi: ≈ 4.768 × 1.880 × 1.530 mm, wheelbase 2.750 mm \r\nautonews.gasgoo.com\r\n+2\r\naionev.my.id\r\n+2\r\npidetucarro.com\r\n+2\r\n.\r\n\r\nInterior premium: dual-layar 12,3″, sunroof, ambient lighting, bangku kulit, ruang bagasi ~453 L \r\naionindonesia.com\r\n.\r\n\r\nFitur canggih ADAS L2+: adaptive cruise, lane assist, blind-spot warning, park assist \r\nhezhongcars.com\r\n.\r\n\r\n🏭 Green Innovation & Produksi Pintar\r\nDibuat di Smart Manufacturing Center, Guangzhou: produksi bodi campuran baja & aluminium dengan 5G, pengawasan digital, dan aliran energi ramah lingkungan (PLTS + pendinginaan hybrid) \r\nasiaone.com\r\n+4\r\nthemalaysianreserve.com\r\n+4\r\nsiamnewsnetwork.net\r\n+4\r\n.\r\n\r\nProduksi memungkinkan kustomisasi cepat & transparan melalui aplikasi, meningkatkan efisiensi hingga 35% \r\nasiaone.com\r\n+4\r\nthemalaysianreserve.com\r\n+4\r\naionindonesia.com\r\n+4\r\n.\r\n\r\n🌍 Posisi Global & Harga\r\nMenggunakan platform AEP 3.0, diproduksi di China & Thailand, diekspor ke Asia Tenggara termasuk Indonesia .\r\n\r\nDi China, harga mulai sekitar US $21.600 (≈ ¥150.000) untuk varian PHEV setara Aion S Plus ', 'Aion S_ Green Innovation on Wheels.jpg', 'tersedia', '2025-06-29 13:13:39'),
(14, 'Honda CR-V', 'Honda', NULL, 2023, 480000000, 'Honda CR-V adalah SUV (Sport Utility Vehicle) yang populer karena kenyamanan, keandalan, efisiensi bahan bakar, dan teknologi canggih. Mobil ini cocok untuk keluarga maupun pengguna yang aktif dan dinamis.\r\n\r\n🔧 Spesifikasi Umum (Tergantung Tahun dan Varian):\r\nTipe Mesin: 1.5L VTEC Turbo / 2.0L i-VTEC / 2.4L (tergantung varian)\r\n\r\nTenaga Maksimal: Sekitar 190 PS pada 5.600 rpm (varian turbo)\r\n\r\nTransmisi: CVT (Continuously Variable Transmission)\r\n\r\nPenggerak: FWD (Front Wheel Drive) atau AWD (All Wheel Drive)\r\n\r\n🛋️ Interior:\r\nKabin luas dengan 5–7 tempat duduk (varian tertentu 7-seater)\r\n\r\nMaterial berkualitas premium\r\n\r\nSistem infotainment layar sentuh 7–9 inci\r\n\r\nDilengkapi Apple CarPlay & Android Auto\r\n\r\nSunroof (pada varian tertentu)\r\n\r\nBagasi luas dan fleksibel\r\n\r\n🛡️ Fitur Keamanan:\r\nHonda Sensing (pada varian terbaru):\r\n\r\nCollision Mitigation Braking System (CMBS)\r\n\r\nAdaptive Cruise Control (ACC)\r\n\r\nLane Keeping Assist System (LKAS)\r\n\r\nRoad Departure Mitigation (RDM)\r\n\r\n6 Airbags\r\n\r\nHill Start Assist (HSA)\r\n\r\nVehicle Stability Assist (VSA)\r\n\r\nKamera belakang dan sensor parkir\r\n\r\n⛽ Konsumsi Bahan Bakar:\r\nSekitar 12–15 km/liter tergantung varian dan kondisi jalan\r\n\r\n🎨 Varian Warna Umum:\r\nLunar Silver Metallic\r\n\r\nModern Steel Metallic\r\n\r\nCrystal Black Pearl\r\n\r\nPlatinum White Pearl\r\n\r\nPassion Red Pearl\r\n\r\n', '2025 Honda CR-V Review_ Expert Insights, Pricing, and Trims.jpg', 'tersedia', '2025-07-08 00:12:27'),
(15, 'Honda BR-V', 'Honda', NULL, 2021, 350400000, 'Kelas & Karoseri\r\nDistrubuat sebagai SUV crossover dengan 7 penumpang, posisi duduk tinggi, cocok untuk keluarga. Tersedia generasi kedua (DG3) sejak Desember 2021. \r\nDimensi (Gen 2) \r\nreddit.com\r\n:\r\n\r\nPanjang: 4.490 mm\r\n\r\nLebar: 1.780 mm\r\n\r\nTinggi: ±1.685 mm\r\n\r\nJarak sumbu roda (wheelbase): 2.700 mm\r\n\r\nJarak ke tanah (ground clearance): 220 mm\r\n\r\nMesin & Transmisi \r\nsumateraekspres.bacakoran.co\r\n+4\r\nautofun.co.id\r\n+4\r\noto.detik.com\r\n+4\r\n:\r\n\r\nMesin 1.5L L15ZF – DOHC i‑VTEC, 4‑silinder, 1.498 cc\r\n\r\nTenaga: 121 PS @6.600 rpm\r\n\r\nTorsi: 145 Nm @4.300 rpm\r\n\r\nTransmisi: Manual 6‑percepatan atau CVT\r\nFitur Utama \r\nreddit.com\r\n+15\r\nhonda-indonesia.com\r\n+15\r\ncvtindonesia.co.id\r\n+15\r\nhonda-indonesia.com\r\n+9\r\nhonda-indonesia.com\r\n+9\r\nautofun.co.id\r\n+9\r\n:\r\n\r\nHead unit layar 7″–9″ touchscreen (varian N7X mendapatkan layar 9″)\r\n\r\nHonda LaneWatch (kamera blind-spot di varian Prestige)\r\n\r\nRemote Engine Start, Smart Entry, Walk‑Away Auto Lock\r\n\r\nRear parking camera, 6‑speaker audio, koneksi Bluetooth/USB\r\n\r\nSuspensi MacPherson Strut depan & H‑Type torsion beam belakang\r\n\r\nMesin sudah Euro 4 certified\r\n\r\nFitur keselamatan aktif “Honda Sensing” di varian tertinggi:\r\nCollision Mitigation Braking System (CMBS), Adaptive Cruise Control (ACC), Lane Keeping Assist (LKAS), Lead Car Departure Notification (LCDN) \r\n', 'Honda BRV 2024.jpg', 'tersedia', '2025-07-09 02:31:48');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama`, `email`, `password`, `no_hp`, `alamat`) VALUES
(2, 'sabet parhusip', 'sabeth@gmail.com', 'sabet', '081364068035', 'Batam'),
(3, 'Elizabeth ', 'elizabeth@gmail.com', '$2y$10$WXwmNJbDqbl2F7.eR2thN.m1tuw./mi5oSHz6FvFf5sDN3lZ7AUZu', '081364068035', 'Batam'),
(4, 'Riel', 'riel@gmail.com', '$2y$10$2DjRfPIWkeF35zxggRqR1OcpfhnhhL9Pu8IjBRi9o/VyB9OOaEay6', NULL, NULL),
(5, 'suci', 'suci@gmail.com', '$2y$10$4EXLWng3aELoez8rgenGxOVim2FYWJwJXb7dYRiPKYvmpLkNLnpwK', NULL, NULL),
(6, 'SABETH', 'sabet@gmail.com', '$2y$10$QDkXIgLACYaHdG5cfpwMS.cW22bOrc5dBCKkdNB1sdjjIq0AUofDK', NULL, NULL),
(7, 'saskia', 'saskia@gmail.com', '$2y$10$i5rObiFyqCGI.2Xm2oUBUOdxsVme3SIcksRdq1tVGecMvV1.oA3l.', NULL, NULL),
(8, 'suci', 'suci123@gmail.com', '$2y$10$tfUNUQKZv3MhuwouTTo5LeyZBOT4CaCyF53Z4dnBpouMBTS9NVF3a', NULL, NULL),
(9, 'gisel', 'admingisel@gmail.com', '$2y$10$L1n86U1dqjx2fH4sz9v/t.DZQlw0eyMt.Ksk/GxwsIEJogpHm4zpy', NULL, NULL),
(10, 'gisel', 'admin123@gmail.com', '$2y$10$fmLel1xYNwmBXPZBqu9xtOhq/.dhdJhZ6gAw8OglLZJK5BikyEDPO', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan`
--

CREATE TABLE `pemesanan` (
  `id_pemesanan` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `id_mobil` int(11) NOT NULL,
  `tanggal_pesan` date NOT NULL,
  `status` varchar(50) DEFAULT 'menunggu konfirmasi'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `id_pesanan` int(11) NOT NULL,
  `id_mobil` int(11) DEFAULT NULL,
  `nama_pemesan` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `pesan` text DEFAULT NULL,
  `tanggal_pesan` timestamp NOT NULL DEFAULT current_timestamp(),
  `metode_pembayaran` enum('Cash','Transfer') DEFAULT 'Cash'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `id_mobil`, `nama_pemesan`, `no_hp`, `email`, `pesan`, `tanggal_pesan`, `metode_pembayaran`) VALUES
(1, 6, 'Riel', '081364068035', 'riel@gmail.com', 'oke', '2025-06-29 09:41:19', 'Cash'),
(2, 4, 'Riel', '081364068035', 'riel@gmail.com', '1', '2025-06-29 09:51:18', 'Cash'),
(3, 4, 'Riel', '081364068035', 'riel@gmail.com', '2', '2025-06-29 09:55:18', 'Cash'),
(4, 6, 'Riel', '081364068035', 'riel@gmail.com', '3', '2025-06-29 10:24:28', 'Cash'),
(5, 7, 'Riel', '081364068035', 'riel@gmail.com', '9', '2025-06-29 10:32:35', 'Cash'),
(6, 13, 'Riel', '081364068035', 'riel@gmail.com', '6', '2025-06-29 13:59:55', 'Cash'),
(7, 13, 'Riel', '081364068035', 'riel@gmail.com', '1', '2025-06-29 14:05:35', 'Cash'),
(8, 13, 'Riel', '081364068035', 'riel@gmail.com', '4', '2025-06-29 14:07:27', 'Cash'),
(9, 13, 'suci', '08999999999', 'suci@gmail.com', 'satu mobil', '2025-07-08 08:01:58', 'Cash'),
(10, 13, 'suci', '08999999999', 'suci@gmail.com', 'satu mobil', '2025-07-08 08:03:25', 'Cash'),
(11, 13, 'suci', '08999999999', 'suci@gmail.com', 'satu mobil', '2025-07-08 08:03:59', 'Cash'),
(12, 13, 'suci', '08666666', 'suci@gmail.com', '4', '2025-07-09 04:42:35', 'Cash'),
(13, 13, 'suci', '08666666', 'suci@gmail.com', '4', '2025-07-09 04:45:50', 'Cash'),
(14, 13, 'suci', '08666666', 'suci@gmail.com', '4', '2025-07-09 04:51:24', 'Cash'),
(15, 13, 'suci', '08666666', 'suci@gmail.com', '4', '2025-07-09 04:53:38', 'Cash'),
(16, 15, 'suci', '08666666', 'suci@gmail.com', '1', '2025-07-09 04:59:27', 'Cash'),
(17, 15, 'suci', '08666666', 'suci@gmail.com', '1', '2025-07-09 06:31:35', 'Cash'),
(18, 13, 'suci', '08666666', 'suci@gmail.com', 'satu mobil', '2025-07-09 06:34:05', 'Cash'),
(19, 15, 'suci', '08666666', 'suci@gmail.com', '1', '2025-07-09 06:40:47', 'Cash'),
(20, 15, 'suci', '08666666', 'suci@gmail.com', '1', '2025-07-09 06:43:50', 'Cash'),
(21, 15, 'suci', '08666666', 'suci@gmail.com', 'satu mobil', '2025-07-09 06:46:46', 'Cash'),
(22, 5, 'suci', '08666666', 'suci@gmail.com', 'Warna merah', '2025-07-09 07:37:53', 'Transfer'),
(23, 9, 'SABETH', '081364068035', 'sabet@gmail.com', 'warna hitam', '2025-07-09 08:02:51', 'Cash');

-- --------------------------------------------------------

--
-- Struktur dari tabel `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `slider`
--

INSERT INTO `slider` (`id`, `gambar`) VALUES
(1, 'slide1.jpg'),
(2, 'slide2.jpg'),
(3, 'slide3.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','pelanggan') NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`id_mobil`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indeks untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`id_pemesanan`),
  ADD KEY `id_pelanggan` (`id_pelanggan`),
  ADD KEY `id_mobil` (`id_mobil`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id_pesanan`),
  ADD KEY `id_mobil` (`id_mobil`);

--
-- Indeks untuk tabel `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `mobil`
--
ALTER TABLE `mobil`
  MODIFY `id_mobil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `id_pemesanan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id_pesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `mobil`
--
ALTER TABLE `mobil`
  ADD CONSTRAINT `mobil_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`);

--
-- Ketidakleluasaan untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD CONSTRAINT `pemesanan_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`),
  ADD CONSTRAINT `pemesanan_ibfk_2` FOREIGN KEY (`id_mobil`) REFERENCES `mobil` (`id_mobil`);

--
-- Ketidakleluasaan untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD CONSTRAINT `pesanan_ibfk_1` FOREIGN KEY (`id_mobil`) REFERENCES `mobil` (`id_mobil`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
