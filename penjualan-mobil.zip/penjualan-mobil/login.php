<?php
session_start();
include 'config/koneksi.php';

$username = $_POST['username'];
$password = md5($_POST['password']);

$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 1) {
    $user = mysqli_fetch_assoc($result);
    
    if ($user['role'] == 'admin') {
        $_SESSION['admin'] = $user;
        header("Location: admin/dashboard.php");
    } else {
        $_SESSION['pelanggan'] = $user;
        header("Location: pelanggan/index.php");
    }
} else {
    echo "<script>
        alert('Username atau password salah!');
        window.location='index.php';
    </script>";
}
?>
